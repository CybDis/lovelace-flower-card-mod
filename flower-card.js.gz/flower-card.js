/*! For license information please see flower-card.js.LICENSE.txt */
(()=>{"use strict";var t={135:(t,e,i)=>{Object.defineProperty(e,"__esModule",{value:!0}),e.moreInfo=e.getStubConfig=e.getConfigElement=void 0;const r=i(356),n=i(139);e.getConfigElement=()=>document.createElement("flower-card-editor"),e.getStubConfig=t=>{const e=Object.values(t.states).filter(t=>0===t.entity_id.indexOf("plant."));return{entity:e.length>0?e[0].entity_id:"plant.my_plant",battery_sensor:"sensor.myflower_battery",show_bars:n.default_show_bars}},e.moreInfo=(t,e)=>{(0,r.fireEvent)(t,"hass-more-info",{entityId:e},{bubbles:!1,composed:!0})}},139:(t,e)=>{Object.defineProperty(e,"__esModule",{value:!0}),e.plantAttributes=e.missingImage=e.default_show_bars=e.CARD_NAME=void 0,e.CARD_NAME="flower-card",e.default_show_bars=["moisture"],e.missingImage="data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHByZXNlcnZlQXNwZWN0UmF0aW89InhNaWRZTWlkIG1lZXQiIGZvY3VzYWJsZT0iZmFsc2UiIHJvbGU9ImltZyIgYXJpYS1oaWRkZW49InRydWUiIHZpZXdCb3g9IjAgMCAyNCAyNCI+CiAgICAgIDxnPgogICAgICA8IS0tP2xpdCQ0MTM0MjMxNjkkLS0+PHBhdGggZD0iTTMsMTNBOSw5IDAgMCwwIDEyLDIyQzEyLDE3IDcuOTcsMTMgMywxM00xMiw1LjVBMi41LDIuNSAwIDAsMSAxNC41LDhBMi41LDIuNSAwIDAsMSAxMiwxMC41QTIuNSwyLjUgMCAwLDEgOS41LDhBMi41LDIuNSAwIDAsMSAxMiw1LjVNNS42LDEwLjI1QTIuNSwyLjUgMCAwLDAgOC4xLDEyLjc1QzguNjMsMTIuNzUgOS4xMiwxMi41OCA5LjUsMTIuMzFDOS41LDEyLjM3IDkuNSwxMi40MyA5LjUsMTIuNUEyLjUsMi41IDAgMCwwIDEyLDE1QTIuNSwyLjUgMCAwLDAgMTQuNSwxMi41QzE0LjUsMTIuNDMgMTQuNSwxMi4zNyAxNC41LDEyLjMxQzE0Ljg4LDEyLjU4IDE1LjM3LDEyLjc1IDE1LjksMTIuNzVDMTcuMjgsMTIuNzUgMTguNCwxMS42MyAxOC40LDEwLjI1QzE4LjQsOS4yNSAxNy44MSw4LjQgMTYuOTcsOEMxNy44MSw3LjYgMTguNCw2Ljc0IDE4LjQsNS43NUMxOC40LDQuMzcgMTcuMjgsMy4yNSAxNS45LDMuMjVDMTUuMzcsMy4yNSAxNC44OCwzLjQxIDE0LjUsMy42OUMxNC41LDMuNjMgMTQuNSwzLjU2IDE0LjUsMy41QTIuNSwyLjUgMCAwLDAgMTIsMUEyLjUsMi41IDAgMCwwIDkuNSwzLjVDOS41LDMuNTYgOS41LDMuNjMgOS41LDMuNjlDOS4xMiwzLjQxIDguNjMsMy4yNSA4LjEsMy4yNUEyLjUsMi41IDAgMCwwIDUuNiw1Ljc1QzUuNiw2Ljc0IDYuMTksNy42IDcuMDMsOEM2LjE5LDguNCA1LjYsOS4yNSA1LjYsMTAuMjVNMTIsMjJBOSw5IDAgMCwwIDIxLDEzQzE2LDEzIDEyLDE3IDEyLDIyWiI+PC9wYXRoPgogICAgICA8L2c+Cjwvc3ZnPgo=",e.plantAttributes=[{label:"Moisture",value:"moisture"},{label:"Conductivity",value:"conductivity"},{label:"Temperature",value:"temperature"},{label:"Illuminance",value:"illuminance"},{label:"Humidity",value:"humidity"},{label:"Daily Light Integral",value:"dli"}]},248:function(t,e,i){var r=this&&this.__decorate||function(t,e,i,r){var n,a=arguments.length,s=a<3?e:null===r?r=Object.getOwnPropertyDescriptor(e,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(t,e,i,r);else for(var o=t.length-1;o>=0;o--)(n=t[o])&&(s=(a<3?n(s):a>3?n(e,i,s):n(e,i))||s);return a>3&&s&&Object.defineProperty(e,i,s),s},n=this&&this.__awaiter||function(t,e,i,r){return new(i||(i=Promise))(function(n,a){function s(t){try{c(r.next(t))}catch(t){a(t)}}function o(t){try{c(r.throw(t))}catch(t){a(t)}}function c(t){var e;t.done?n(t.value):(e=t.value,e instanceof i?e:new i(function(t){t(e)})).then(s,o)}c((r=r.apply(t,e||[])).next())})};Object.defineProperty(e,"__esModule",{value:!0});const a=i(337),s=i(924),o=i(800),c=i(854),l=i(330),u=i(429),d=i(139),h=i(135);console.info(`%c FLOWER-CARD %c ${l.version}`,"color: cyan; background: black; font-weight: bold;","color: darkblue; background: white; font-weight: bold;"),window.customCards=window.customCards||[],window.customCards.push({type:d.CARD_NAME,name:"Flower card",preview:!0,description:"Custom flower card for https://github.com/Olen/homeassistant-plant"});let m=class extends a.LitElement{connectedCallback(){super.connectedCallback(),this._freshnessTimer||(this._freshnessTimer=window.setInterval(()=>this.requestUpdate(),6e4))}disconnectedCallback(){super.disconnectedCallback(),this._freshnessTimer&&(window.clearInterval(this._freshnessTimer),this._freshnessTimer=void 0)}set hass(t){var e,i;this._hass=t,this.stateObj=(null===(e=this.config)||void 0===e?void 0:e.entity)?t.states[this.config.entity]:void 0,!(null===(i=this.config)||void 0===i?void 0:i.name)&&this.stateObj&&(this.config=Object.assign(Object.assign({},this.config),{name:this.stateObj.attributes.friendly_name})),this.previousFetchDate||(this.previousFetchDate=0),Date.now()>this.previousFetchDate+1e3&&(this.previousFetchDate=Date.now(),this.get_data(t).then(()=>{this.requestUpdate()}))}static getConfigForm(){return{schema:[{name:"display_type",selector:{select:{options:[{label:"Full",value:c.DisplayType.Full},{label:"Compact",value:c.DisplayType.Compact}]}}},{name:"entity",required:!0,selector:{entity:{domain:"plant"}}},{name:"name",selector:{text:{}}},{name:"battery_sensor",selector:{entity:{domain:"sensor",device_class:"battery"}}},{name:"show_bars",selector:{select:{multiple:!0,options:[{label:"Moisture",value:"moisture"},{label:"Conductivity",value:"conductivity"},{label:"Temperature",value:"temperature"},{label:"Illuminance",value:"illuminance"},{label:"Humidity",value:"humidity"},{label:"Daily Light Integral",value:"dli"}]}}},{name:"hide_species",selector:{boolean:{}}},{name:"hide_image",selector:{boolean:{}}}],computeLabel:t=>({display_type:"Display Type",entity:"Entity",name:"Name",battery_sensor:"Battery Sensor",show_bars:"Show Bars",hide_species:"Hide Species",hide_image:"Hide Image"}[t.name]||t.name)}}static getStubConfig(t){const e=Object.values(t.states).filter(t=>0===t.entity_id.indexOf("plant."));return{entity:e.length>0?e[0].entity_id:"plant.my_plant",battery_sensor:"sensor.myflower_battery",show_bars:d.default_show_bars}}setConfig(t){if(!t.entity)throw new Error("You need to define an entity");this.config=t}render(){var t;if(!this.config||!this._hass)return a.html``;if(!this.stateObj)return a.html`
                <hui-warning>
                Entity not available: ${this.config.entity}
                </hui-warning>
              `;const e=this.stateObj.attributes.species,i=void 0!==this.config.hide_species&&this.config.hide_species,r=null!==(t=this.config.hide_image)&&void 0!==t&&t,n=this.config.display_type===c.DisplayType.Compact?"header-compact":"header",s=this.config.display_type===c.DisplayType.Compact||r?"":"card-margin-top",o=r?" no-image":"",l=(0,u.renderBattery)(this),m=l.isStale,p=(0,u.renderSensorFreshness)(this),g="problem"===this.stateObj.state.toLowerCase(),f=`${s} ${g?"problem-state":m?"battery-warning-state":""}`.trim();return a.html`
            <ha-card class="${f}">
            <div class="${n}${o}" @click="${()=>(0,h.moreInfo)(this,this.stateObj.entity_id)}">
                ${r?"":a.html`<img src="${this.stateObj.attributes.entity_picture?this.stateObj.attributes.entity_picture:d.missingImage}">`}
                <span id="name"> ${this.config.name} <ha-icon .icon="mdi:${g?"alert-circle-outline":""}"></ha-icon>
                </span>
                <span id="sensor-freshness">${p.html}</span>
                <span id="battery">${l.html}</span>
                ${i?"":a.html`<span id="species">${e} </span>`}
            </div>
            ${this.config.display_type!==c.DisplayType.Compact?a.html`<div class="divider"></div>`:""}
            ${(0,u.renderAttributes)(this)}
            </ha-card>
            `}get_data(t){return n(this,void 0,void 0,function*(){var e;try{this.plantinfo=yield t.callWS({type:"plant/get_info",entity_id:null===(e=this.config)||void 0===e?void 0:e.entity})}catch(t){this.plantinfo={result:{}}}})}getCardSize(){return 5}static get styles(){return o.style}};r([(0,s.property)()],m.prototype,"_hass",void 0),r([(0,s.property)()],m.prototype,"config",void 0),m=r([(0,s.customElement)(d.CARD_NAME)],m),e.default=m},330:t=>{t.exports=JSON.parse('{"name":"flower-card","version":"2026.7.5-beta.3","description":"Custom flower card for https://github.com/Olen/homeassistant-plant","keywords":["home-assistant","homeassistant","lovelace","custom-cards"],"module":"flower-card.js","license":"MIT","private":false,"dependencies":{"@babel/preset-env":"^7.28.3","@marcokreeft/ha-editor-formbuilder":"^2024.9.1","compression-webpack-plugin":"^11.1.0","custom-card-helpers":"^1.9.0","home-assistant-js-websocket":"^9.5.0","lit":"^3.3.1","webpack":"^5.101.3","yarn":"^1.22.22"},"scripts":{"lint":"eslint src/**/*.ts","dev":"webpack -c webpack.config.js","build":"yarn lint && webpack -c webpack.config.js"},"devDependencies":{"@typescript-eslint/eslint-plugin":"^8.42.0","babel-loader":"^10.0.0","eslint":"^9.34.0","ts-loader":"^9.5.4","typescript":"^5.9.2","webpack-cli":"^6.0.1"}}')},337:(t,e,i)=>{i.r(e),i.d(e,{CSSResult:()=>r.BO,LitElement:()=>s,ReactiveElement:()=>r.mN,_$LE:()=>c,_$LH:()=>n.ge,adoptStyles:()=>r.Rf,css:()=>r.AH,defaultConverter:()=>r.W3,getCompatibleStyle:()=>r.sk,html:()=>n.qy,isServer:()=>l,mathml:()=>n.ej,noChange:()=>n.c0,notEqual:()=>r.Ec,nothing:()=>n.s6,render:()=>n.XX,supportsAdoptingStyleSheets:()=>r.qM,svg:()=>n.JW,unsafeCSS:()=>r.iz});var r=i(842),n=i(752);const a=globalThis;class s extends r.mN{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const t=super.createRenderRoot();return this.renderOptions.renderBefore??=t.firstChild,t}update(t){const e=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(t),this._$Do=(0,n.XX)(e,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return n.c0}}s._$litElement$=!0,s.finalized=!0,a.litElementHydrateSupport?.({LitElement:s});const o=a.litElementPolyfillSupport;o?.({LitElement:s});const c={_$AK:(t,e,i)=>{t._$AK(e,i)},_$AL:t=>t._$AL};(a.litElementVersions??=[]).push("4.2.1");const l=!1},356:(t,e,i)=>{i.r(e),i.d(e,{DEFAULT_DOMAIN_ICON:()=>J,DEFAULT_PANEL:()=>K,DEFAULT_VIEW_ENTITY_ID:()=>ot,DOMAINS_HIDE_MORE_INFO:()=>et,DOMAINS_MORE_INFO_NO_HISTORY:()=>it,DOMAINS_TOGGLE:()=>nt,DOMAINS_WITH_CARD:()=>G,DOMAINS_WITH_MORE_INFO:()=>tt,NumberFormat:()=>r,STATES_OFF:()=>rt,TimeFormat:()=>n,UNIT_C:()=>at,UNIT_F:()=>st,applyThemesOnElement:()=>P,computeCardSize:()=>R,computeDomain:()=>z,computeEntity:()=>F,computeRTL:()=>H,computeRTLDirection:()=>q,computeStateDisplay:()=>X,computeStateDomain:()=>B,createThing:()=>dt,debounce:()=>ht,domainIcon:()=>pt,evaluateFilter:()=>gt,fireEvent:()=>ct,fixedIcons:()=>mt,formatDate:()=>u,formatDateMonth:()=>y,formatDateMonthYear:()=>f,formatDateNumeric:()=>h,formatDateShort:()=>p,formatDateTime:()=>x,formatDateTimeNumeric:()=>D,formatDateTimeWithSeconds:()=>M,formatDateWeekday:()=>c,formatDateYear:()=>v,formatNumber:()=>Z,formatTime:()=>k,formatTimeWeekday:()=>I,formatTimeWithSeconds:()=>C,forwardHaptic:()=>ft,getLovelace:()=>Dt,handleAction:()=>wt,handleActionConfig:()=>vt,handleClick:()=>$t,hasAction:()=>xt,hasConfigOrEntityChanged:()=>At,hasDoubleClick:()=>Mt,isNumericState:()=>W,navigate:()=>bt,numberFormatToLocale:()=>Y,relativeTime:()=>L,round:()=>Q,stateIcon:()=>Nt,timerTimeRemaining:()=>j,toggleEntity:()=>_t,turnOnOffEntities:()=>St,turnOnOffEntity:()=>yt});var r,n,a,s=function(){return s=Object.assign||function(t){for(var e,i=1,r=arguments.length;i<r;i++)for(var n in e=arguments[i])Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n]);return t},s.apply(this,arguments)},o={second:45,minute:45,hour:22,day:5},c=function(t,e){return l(e).format(t)},l=function(t){return new Intl.DateTimeFormat(t.language,{weekday:"long",month:"long",day:"numeric"})},u=function(t,e){return d(e).format(t)},d=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric"})},h=function(t,e){return m(e).format(t)},m=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"numeric",day:"numeric"})},p=function(t,e){return g(e).format(t)},g=function(t){return new Intl.DateTimeFormat(t.language,{day:"numeric",month:"short"})},f=function(t,e){return b(e).format(t)},b=function(t){return new Intl.DateTimeFormat(t.language,{month:"long",year:"numeric"})},y=function(t,e){return _(e).format(t)},_=function(t){return new Intl.DateTimeFormat(t.language,{month:"long"})},v=function(t,e){return w(e).format(t)},w=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric"})};(a=r||(r={})).language="language",a.system="system",a.comma_decimal="comma_decimal",a.decimal_comma="decimal_comma",a.space_comma="space_comma",a.none="none",function(t){t.language="language",t.system="system",t.am_pm="12",t.twenty_four="24"}(n||(n={}));var $=function(t){if(t.time_format===n.language||t.time_format===n.system){var e=t.time_format===n.language?t.language:void 0,i=(new Date).toLocaleString(e);return i.includes("AM")||i.includes("PM")}return t.time_format===n.am_pm},x=function(t,e){return A(e).format(t)},A=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:$(t)?"numeric":"2-digit",minute:"2-digit",hour12:$(t)})},M=function(t,e){return S(e).format(t)},S=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:$(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hour12:$(t)})},D=function(t,e){return E(e).format(t)},E=function(t){return new Intl.DateTimeFormat(t.language,{year:"numeric",month:"numeric",day:"numeric",hour:"numeric",minute:"2-digit",hour12:$(t)})},k=function(t,e){return N(e).format(t)},N=function(t){return new Intl.DateTimeFormat(t.language,{hour:"numeric",minute:"2-digit",hour12:$(t)})},C=function(t,e){return T(e).format(t)},T=function(t){return new Intl.DateTimeFormat(t.language,{hour:$(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hour12:$(t)})},I=function(t,e){return O(e).format(t)},O=function(t){return new Intl.DateTimeFormat(t.language,{hour:$(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hour12:$(t)})},L=function(t,e,i,r){void 0===r&&(r=!0);var n=function(t,e,i){void 0===e&&(e=Date.now()),void 0===i&&(i={});var r=s(s({},o),i||{}),n=(+t-+e)/1e3;if(Math.abs(n)<r.second)return{value:Math.round(n),unit:"second"};var a=n/60;if(Math.abs(a)<r.minute)return{value:Math.round(a),unit:"minute"};var c=n/3600;if(Math.abs(c)<r.hour)return{value:Math.round(c),unit:"hour"};var l=n/86400;if(Math.abs(l)<r.day)return{value:Math.round(l),unit:"day"};var u=new Date(t),d=new Date(e),h=u.getFullYear()-d.getFullYear();if(Math.round(Math.abs(h))>0)return{value:Math.round(h),unit:"year"};var m=12*h+u.getMonth()-d.getMonth();if(Math.round(Math.abs(m))>0)return{value:Math.round(m),unit:"month"};var p=n/604800;return{value:Math.round(p),unit:"week"}}(t,i);return r?function(t){return new Intl.RelativeTimeFormat(t.language,{numeric:"auto"})}(e).format(n.value,n.unit):Intl.NumberFormat(e.language,{style:"unit",unit:n.unit,unitDisplay:"long"}).format(Math.abs(n.value))};function j(t){var e,i=3600*(e=t.attributes.remaining.split(":").map(Number))[0]+60*e[1]+e[2];if("active"===t.state){var r=(new Date).getTime(),n=new Date(t.last_changed).getTime();i=Math.max(i-(r-n)/1e3,0)}return i}function U(){return(U=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var i=arguments[e];for(var r in i)Object.prototype.hasOwnProperty.call(i,r)&&(t[r]=i[r])}return t}).apply(this,arguments)}var P=function(t,e,i,r){void 0===r&&(r=!1),t._themes||(t._themes={});var n=e.default_theme;("default"===i||i&&e.themes[i])&&(n=i);var a=U({},t._themes);if("default"!==n){var s=e.themes[n];Object.keys(s).forEach(function(e){var i="--"+e;t._themes[i]="",a[i]=s[e]})}if(t.updateStyles?t.updateStyles(a):window.ShadyCSS&&window.ShadyCSS.styleSubtree(t,a),r){var o=document.querySelector("meta[name=theme-color]");if(o){o.hasAttribute("default-content")||o.setAttribute("default-content",o.getAttribute("content"));var c=a["--primary-color"]||o.getAttribute("default-content");o.setAttribute("content",c)}}},R=function(t){return"function"==typeof t.getCardSize?t.getCardSize():4};function z(t){return t.substr(0,t.indexOf("."))}function F(t){return t.substr(t.indexOf(".")+1)}function H(t){var e,i=(null==t||null==(e=t.locale)?void 0:e.language)||"en";return t.translationMetadata.translations[i]&&t.translationMetadata.translations[i].isRTL||!1}function q(t){return H(t)?"rtl":"ltr"}function B(t){return z(t.entity_id)}var W=function(t){return!!t.attributes.unit_of_measurement||!!t.attributes.state_class},Y=function(t){switch(t.number_format){case r.comma_decimal:return["en-US","en"];case r.decimal_comma:return["de","es","it"];case r.space_comma:return["fr","sv","cs"];case r.system:return;default:return t.language}},Q=function(t,e){return void 0===e&&(e=2),Math.round(t*Math.pow(10,e))/Math.pow(10,e)},Z=function(t,e,i){var n=e?Y(e):void 0;if(Number.isNaN=Number.isNaN||function t(e){return"number"==typeof e&&t(e)},(null==e?void 0:e.number_format)!==r.none&&!Number.isNaN(Number(t))&&Intl)try{return new Intl.NumberFormat(n,V(t,i)).format(Number(t))}catch(e){return console.error(e),new Intl.NumberFormat(void 0,V(t,i)).format(Number(t))}return"string"==typeof t?t:Q(t,null==i?void 0:i.maximumFractionDigits).toString()+("currency"===(null==i?void 0:i.style)?" "+i.currency:"")},V=function(t,e){var i=U({maximumFractionDigits:2},e);if("string"!=typeof t)return i;if(!e||!e.minimumFractionDigits&&!e.maximumFractionDigits){var r=t.indexOf(".")>-1?t.split(".")[1].length:0;i.minimumFractionDigits=r,i.maximumFractionDigits=r}return i},X=function(t,e,i,r){var n=void 0!==r?r:e.state;if("unknown"===n||"unavailable"===n)return t("state.default."+n);if(W(e)){if("monetary"===e.attributes.device_class)try{return Z(n,i,{style:"currency",currency:e.attributes.unit_of_measurement})}catch(t){}return Z(n,i)+(e.attributes.unit_of_measurement?" "+e.attributes.unit_of_measurement:"")}var a=B(e);if("input_datetime"===a){var s;if(void 0===r)return e.attributes.has_date&&e.attributes.has_time?(s=new Date(e.attributes.year,e.attributes.month-1,e.attributes.day,e.attributes.hour,e.attributes.minute),x(s,i)):e.attributes.has_date?(s=new Date(e.attributes.year,e.attributes.month-1,e.attributes.day),u(s,i)):e.attributes.has_time?((s=new Date).setHours(e.attributes.hour,e.attributes.minute),k(s,i)):e.state;try{var o=r.split(" ");if(2===o.length)return x(new Date(o.join("T")),i);if(1===o.length){if(r.includes("-"))return u(new Date(r+"T00:00"),i);if(r.includes(":")){var c=new Date;return k(new Date(c.toISOString().split("T")[0]+"T"+r),i)}}return r}catch(t){return r}}return"humidifier"===a&&"on"===n&&e.attributes.humidity?e.attributes.humidity+" %":"counter"===a||"number"===a||"input_number"===a?Z(n,i):e.attributes.device_class&&t("component."+a+".state."+e.attributes.device_class+"."+n)||t("component."+a+".state._."+n)||n},J="mdi:bookmark",K="lovelace",G=["climate","cover","configurator","input_select","input_number","input_text","lock","media_player","scene","script","timer","vacuum","water_heater","weblink"],tt=["alarm_control_panel","automation","camera","climate","configurator","cover","fan","group","history_graph","input_datetime","light","lock","media_player","script","sun","updater","vacuum","water_heater","weather"],et=["input_number","input_select","input_text","scene","weblink"],it=["camera","configurator","history_graph","scene"],rt=["closed","locked","off"],nt=new Set(["fan","input_boolean","light","switch","group","automation"]),at="°C",st="°F",ot="group.default_view",ct=function(t,e,i,r){r=r||{},i=null==i?{}:i;var n=new Event(e,{bubbles:void 0===r.bubbles||r.bubbles,cancelable:Boolean(r.cancelable),composed:void 0===r.composed||r.composed});return n.detail=i,t.dispatchEvent(n),n},lt=new Set(["call-service","divider","section","weblink","cast","select"]),ut={alert:"toggle",automation:"toggle",climate:"climate",cover:"cover",fan:"toggle",group:"group",input_boolean:"toggle",input_number:"input-number",input_select:"input-select",input_text:"input-text",light:"toggle",lock:"lock",media_player:"media-player",remote:"toggle",scene:"scene",script:"script",sensor:"sensor",timer:"timer",switch:"toggle",vacuum:"toggle",water_heater:"climate",input_datetime:"input-datetime"},dt=function(t,e){void 0===e&&(e=!1);var i=function(t,e){return r("hui-error-card",{type:"error",error:t,config:e})},r=function(t,e){var r=window.document.createElement(t);try{if(!r.setConfig)return;r.setConfig(e)}catch(r){return console.error(t,r),i(r.message,e)}return r};if(!t||"object"!=typeof t||!e&&!t.type)return i("No type defined",t);var n=t.type;if(n&&n.startsWith("custom:"))n=n.substr(7);else if(e)if(lt.has(n))n="hui-"+n+"-row";else{if(!t.entity)return i("Invalid config given.",t);var a=t.entity.split(".",1)[0];n="hui-"+(ut[a]||"text")+"-entity-row"}else n="hui-"+n+"-card";if(customElements.get(n))return r(n,t);var s=i("Custom element doesn't exist: "+t.type+".",t);s.style.display="None";var o=setTimeout(function(){s.style.display=""},2e3);return customElements.whenDefined(t.type).then(function(){clearTimeout(o),ct(s,"ll-rebuild",{},s)}),s},ht=function(t,e,i){var r;return void 0===i&&(i=!1),function(){var n=[].slice.call(arguments),a=this,s=i&&!r;clearTimeout(r),r=setTimeout(function(){r=null,i||t.apply(a,n)},e),s&&t.apply(a,n)}},mt={alert:"mdi:alert",automation:"mdi:playlist-play",calendar:"mdi:calendar",camera:"mdi:video",climate:"mdi:thermostat",configurator:"mdi:settings",conversation:"mdi:text-to-speech",device_tracker:"mdi:account",fan:"mdi:fan",group:"mdi:google-circles-communities",history_graph:"mdi:chart-line",homeassistant:"mdi:home-assistant",homekit:"mdi:home-automation",image_processing:"mdi:image-filter-frames",input_boolean:"mdi:drawing",input_datetime:"mdi:calendar-clock",input_number:"mdi:ray-vertex",input_select:"mdi:format-list-bulleted",input_text:"mdi:textbox",light:"mdi:lightbulb",mailbox:"mdi:mailbox",notify:"mdi:comment-alert",person:"mdi:account",plant:"mdi:flower",proximity:"mdi:apple-safari",remote:"mdi:remote",scene:"mdi:google-pages",script:"mdi:file-document",sensor:"mdi:eye",simple_alarm:"mdi:bell",sun:"mdi:white-balance-sunny",switch:"mdi:flash",timer:"mdi:timer",updater:"mdi:cloud-upload",vacuum:"mdi:robot-vacuum",water_heater:"mdi:thermometer",weblink:"mdi:open-in-new"};function pt(t,e){if(t in mt)return mt[t];switch(t){case"alarm_control_panel":switch(e){case"armed_home":return"mdi:bell-plus";case"armed_night":return"mdi:bell-sleep";case"disarmed":return"mdi:bell-outline";case"triggered":return"mdi:bell-ring";default:return"mdi:bell"}case"binary_sensor":return e&&"off"===e?"mdi:radiobox-blank":"mdi:checkbox-marked-circle";case"cover":return"closed"===e?"mdi:window-closed":"mdi:window-open";case"lock":return e&&"unlocked"===e?"mdi:lock-open":"mdi:lock";case"media_player":return e&&"off"!==e&&"idle"!==e?"mdi:cast-connected":"mdi:cast";case"zwave":switch(e){case"dead":return"mdi:emoticon-dead";case"sleeping":return"mdi:sleep";case"initializing":return"mdi:timer-sand";default:return"mdi:z-wave"}default:return console.warn("Unable to find icon for domain "+t+" ("+e+")"),"mdi:bookmark"}}var gt=function(t,e){var i=e.value||e,r=e.attribute?t.attributes[e.attribute]:t.state;switch(e.operator||"=="){case"==":return r===i;case"<=":return r<=i;case"<":return r<i;case">=":return r>=i;case">":return r>i;case"!=":return r!==i;case"regex":return r.match(i);default:return!1}},ft=function(t){ct(window,"haptic",t)},bt=function(t,e,i){void 0===i&&(i=!1),i?history.replaceState(null,"",e):history.pushState(null,"",e),ct(window,"location-changed",{replace:i})},yt=function(t,e,i){void 0===i&&(i=!0);var r,n=z(e),a="group"===n?"homeassistant":n;switch(n){case"lock":r=i?"unlock":"lock";break;case"cover":r=i?"open_cover":"close_cover";break;default:r=i?"turn_on":"turn_off"}return t.callService(a,r,{entity_id:e})},_t=function(t,e){var i=rt.includes(t.states[e].state);return yt(t,e,i)},vt=function(t,e,i,r){if(r||(r={action:"more-info"}),!r.confirmation||r.confirmation.exemptions&&r.confirmation.exemptions.some(function(t){return t.user===e.user.id})||(ft("warning"),confirm(r.confirmation.text||"Are you sure you want to "+r.action+"?")))switch(r.action){case"more-info":(i.entity||i.camera_image)&&ct(t,"hass-more-info",{entityId:i.entity?i.entity:i.camera_image});break;case"navigate":r.navigation_path&&bt(0,r.navigation_path);break;case"url":r.url_path&&window.open(r.url_path);break;case"toggle":i.entity&&(_t(e,i.entity),ft("success"));break;case"call-service":if(!r.service)return void ft("failure");var n=r.service.split(".",2);e.callService(n[0],n[1],r.service_data,r.target),ft("success");break;case"fire-dom-event":ct(t,"ll-custom",r)}},wt=function(t,e,i,r){var n;"double_tap"===r&&i.double_tap_action?n=i.double_tap_action:"hold"===r&&i.hold_action?n=i.hold_action:"tap"===r&&i.tap_action&&(n=i.tap_action),vt(t,e,i,n)},$t=function(t,e,i,r,n){var a;if(n&&i.double_tap_action?a=i.double_tap_action:r&&i.hold_action?a=i.hold_action:!r&&i.tap_action&&(a=i.tap_action),a||(a={action:"more-info"}),!a.confirmation||a.confirmation.exemptions&&a.confirmation.exemptions.some(function(t){return t.user===e.user.id})||confirm(a.confirmation.text||"Are you sure you want to "+a.action+"?"))switch(a.action){case"more-info":(a.entity||i.entity||i.camera_image)&&(ct(t,"hass-more-info",{entityId:a.entity?a.entity:i.entity?i.entity:i.camera_image}),a.haptic&&ft(a.haptic));break;case"navigate":a.navigation_path&&(bt(0,a.navigation_path),a.haptic&&ft(a.haptic));break;case"url":a.url_path&&window.open(a.url_path),a.haptic&&ft(a.haptic);break;case"toggle":i.entity&&(_t(e,i.entity),a.haptic&&ft(a.haptic));break;case"call-service":if(!a.service)return;var s=a.service.split(".",2),o=s[0],c=s[1],l=U({},a.service_data);"entity"===l.entity_id&&(l.entity_id=i.entity),e.callService(o,c,l,a.target),a.haptic&&ft(a.haptic);break;case"fire-dom-event":ct(t,"ll-custom",a),a.haptic&&ft(a.haptic)}};function xt(t){return void 0!==t&&"none"!==t.action}function At(t,e,i){if(e.has("config")||i)return!0;if(t.config.entity){var r=e.get("hass");return!r||r.states[t.config.entity]!==t.hass.states[t.config.entity]}return!1}function Mt(t){return void 0!==t&&"none"!==t.action}var St=function(t,e,i){void 0===i&&(i=!0);var r={};e.forEach(function(e){if(rt.includes(t.states[e].state)===i){var n=z(e),a=["cover","lock"].includes(n)?n:"homeassistant";a in r||(r[a]=[]),r[a].push(e)}}),Object.keys(r).forEach(function(e){var n;switch(e){case"lock":n=i?"unlock":"lock";break;case"cover":n=i?"open_cover":"close_cover";break;default:n=i?"turn_on":"turn_off"}t.callService(e,n,{entity_id:r[e]})})},Dt=function(){var t=document.querySelector("home-assistant");if(t=(t=(t=(t=(t=(t=(t=(t=t&&t.shadowRoot)&&t.querySelector("home-assistant-main"))&&t.shadowRoot)&&t.querySelector("app-drawer-layout partial-panel-resolver"))&&t.shadowRoot||t)&&t.querySelector("ha-panel-lovelace"))&&t.shadowRoot)&&t.querySelector("hui-root")){var e=t.lovelace;return e.current_view=t.___curView,e}return null},Et={humidity:"mdi:water-percent",illuminance:"mdi:brightness-5",temperature:"mdi:thermometer",pressure:"mdi:gauge",power:"mdi:flash",signal_strength:"mdi:wifi"},kt={binary_sensor:function(t,e){var i="off"===t;switch(null==e?void 0:e.attributes.device_class){case"battery":return i?"mdi:battery":"mdi:battery-outline";case"battery_charging":return i?"mdi:battery":"mdi:battery-charging";case"cold":return i?"mdi:thermometer":"mdi:snowflake";case"connectivity":return i?"mdi:server-network-off":"mdi:server-network";case"door":return i?"mdi:door-closed":"mdi:door-open";case"garage_door":return i?"mdi:garage":"mdi:garage-open";case"power":case"plug":return i?"mdi:power-plug-off":"mdi:power-plug";case"gas":case"problem":case"safety":case"tamper":return i?"mdi:check-circle":"mdi:alert-circle";case"smoke":return i?"mdi:check-circle":"mdi:smoke";case"heat":return i?"mdi:thermometer":"mdi:fire";case"light":return i?"mdi:brightness-5":"mdi:brightness-7";case"lock":return i?"mdi:lock":"mdi:lock-open";case"moisture":return i?"mdi:water-off":"mdi:water";case"motion":return i?"mdi:walk":"mdi:run";case"occupancy":case"presence":return i?"mdi:home-outline":"mdi:home";case"opening":return i?"mdi:square":"mdi:square-outline";case"running":return i?"mdi:stop":"mdi:play";case"sound":return i?"mdi:music-note-off":"mdi:music-note";case"update":return i?"mdi:package":"mdi:package-up";case"vibration":return i?"mdi:crop-portrait":"mdi:vibrate";case"window":return i?"mdi:window-closed":"mdi:window-open";default:return i?"mdi:radiobox-blank":"mdi:checkbox-marked-circle"}},cover:function(t){var e="closed"!==t.state;switch(t.attributes.device_class){case"garage":return e?"mdi:garage-open":"mdi:garage";case"door":return e?"mdi:door-open":"mdi:door-closed";case"shutter":return e?"mdi:window-shutter-open":"mdi:window-shutter";case"blind":return e?"mdi:blinds-open":"mdi:blinds";case"window":return e?"mdi:window-open":"mdi:window-closed";default:return pt("cover",t.state)}},sensor:function(t){var e=t.attributes.device_class;if(e&&e in Et)return Et[e];if("battery"===e){var i=Number(t.state);if(isNaN(i))return"mdi:battery-unknown";var r=10*Math.round(i/10);return r>=100?"mdi:battery":r<=0?"mdi:battery-alert":"hass:battery-"+r}var n=t.attributes.unit_of_measurement;return"°C"===n||"°F"===n?"mdi:thermometer":pt("sensor")},input_datetime:function(t){return t.attributes.has_date?t.attributes.has_time?pt("input_datetime"):"mdi:calendar":"mdi:clock"}},Nt=function(t){if(!t)return"mdi:bookmark";if(t.attributes.icon)return t.attributes.icon;var e=z(t.entity_id);return e in kt?kt[e](t):pt(e,t.state)}},429:(t,e,i)=>{Object.defineProperty(e,"__esModule",{value:!0}),e.renderAttributeChunks=e.getChunkedDisplayed=e.renderAttribute=e.renderAttributes=e.renderSensorFreshness=e.renderBattery=void 0;const r=i(854),n=i(337),a=i(534),s=i(139),o=i(135);e.renderBattery=t=>{var e,i;if(!t.config.battery_sensor)return{html:n.html``,isStale:!1};const r=t._hass.states[t.config.battery_sensor];if(!r)return{html:n.html``,isStale:!1};const a=parseInt(r.state);let s=new Date(r.last_updated),c=!1;const l=t.config.battery_sensor;let u=l.replace(/_battery$/,"_updated");u===l&&(u=l.replace(/_batt(?:ery)?(?:_percent|_level)?$/,"_updated")),u===l&&(u=l.replace(/_[^_]+$/,"_updated"));const d=t._hass.states[u];if(d){const t=d.state,e=new Date(t),i=2e3;if(!isNaN(e.getTime())&&e.getFullYear()>=i)s=e;else{const t=new Date(d.last_changed);isNaN(t.getTime())||(s=t)}}const h=new Date;c=Math.floor((h.getTime()-s.getTime())/1e3/60)>540||"unavailable"===r.state||"unknown"===r.state;const m=l.replace(/_battery$/,"_charging");let p=!1;if(m!==l){const e=t._hass.states[m];e&&"charging"===e.state.toLowerCase()&&(p=!0)}let{icon:g,color:f}=[{threshold:90,icon:"mdi:battery",color:"green"},{threshold:80,icon:"mdi:battery-90",color:"green"},{threshold:70,icon:"mdi:battery-80",color:"green"},{threshold:60,icon:"mdi:battery-70",color:"green"},{threshold:50,icon:"mdi:battery-60",color:"green"},{threshold:40,icon:"mdi:battery-50",color:"green"},{threshold:30,icon:"mdi:battery-40",color:"orange"},{threshold:20,icon:"mdi:battery-30",color:"orange"},{threshold:10,icon:"mdi:battery-20",color:"red"},{threshold:0,icon:"mdi:battery-10",color:"red"},{threshold:-1/0,icon:"mdi:battery-alert-variant-outline",color:"red"}].find(({threshold:t})=>a>t)||{icon:"mdi:battery-alert-variant-outline",color:"red"};return p?(g=null!==(i=null===(e=[{threshold:90,icon:"mdi:battery-charging-100"},{threshold:80,icon:"mdi:battery-charging-90"},{threshold:70,icon:"mdi:battery-charging-80"},{threshold:60,icon:"mdi:battery-charging-60"},{threshold:50,icon:"mdi:battery-charging-50"},{threshold:40,icon:"mdi:battery-charging-40"},{threshold:30,icon:"mdi:battery-charging-30"},{threshold:20,icon:"mdi:battery-charging-20"},{threshold:-1/0,icon:"mdi:battery-charging-10"}].find(({threshold:t})=>a>t))||void 0===e?void 0:e.icon)&&void 0!==i?i:"mdi:battery-charging-10",f="var(--info-color, #039be5)"):c&&(g="mdi:battery-alert",f="var(--warning-color, orange)"),{html:n.html`
            <div class="battery tooltip" @click="${e=>{e.stopPropagation(),(0,o.moreInfo)(t,t.config.battery_sensor)}}">
                <div class="tip" style="text-align:center;">${a}%</div>
                <ha-icon .icon="${g}" style="color: ${f}"></ha-icon>
            </div>
        `,isStale:c}},e.renderSensorFreshness=t=>{let e=null;if(t.config.battery_sensor){const i=t.config.battery_sensor;let r=i.replace(/_battery$/,"_updated");r===i&&(r=i.replace(/_batt(?:ery)?(?:_percent|_level)?$/,"_updated")),r===i&&(r=i.replace(/_[^_]+$/,"_updated"));const n=t._hass.states[r];if(n){const t=new Date(n.state),i=2e3;if(!isNaN(t.getTime())&&t.getFullYear()>=i)e=t.getTime();else{const t=new Date(n.last_changed).getTime();isNaN(t)||(e=t)}}if(null===e){const r=t._hass.states[i];if(r){const t=new Date(r.last_updated).getTime();isNaN(t)||(e=t)}}}else{const i=t.config.show_bars||s.default_show_bars,r=[];if(t.plantinfo&&t.plantinfo.result)for(const e of i){const i=t.plantinfo.result[e];i&&i.sensor&&r.push(String(i.sensor))}for(const i of r){const r=t._hass.states[i];if(!r)continue;const n=new Date(r.last_updated).getTime();isNaN(n)||(null===e||n>e)&&(e=n)}}if(null===e)return{html:n.html`<div class="freshness-badge unknown" title="Kein Update-Zeitstempel verfügbar">—</div>`};const i=Math.max(0,Math.floor((Date.now()-e)/6e4));let r;return r=i<=90?"fresh":i<=180?"warn":"stale",{html:n.html`<div class="freshness-badge ${r}" title="Letztes Sensor-Update vor ${i} min">${i}m</div>`}},e.renderAttributes=t=>{const i={},r={},n={},a={},o={},c={},l={},u=t.config.show_bars||s.default_show_bars;if(t.plantinfo&&t.plantinfo.result){const e=t.plantinfo.result;for(const t of u)if(e[t]){let{max:s,min:u,current:d,icon:h,sensor:m,unit_of_measurement:p}=e[t];s=Number(s),u=Number(u),h=String(h),m=String(m),d=Number(d),p=String(p),a[`max_${t}`]={max:s,min:u},o[t]=d,i[t]=h,c[t]=m,n[t]=p,r[t]=p,"dli"===t&&(n.dli="mol/d⋅m²",r.dli='<math style="display: inline-grid;" xmlns="http://www.w3.org/1998/Math/MathML"><mrow><mfrac><mrow><mn>mol</mn></mrow><mrow><mn>d</mn><mn>⋅</mn><msup><mn>m</mn><mn>2</mn></msup></mrow></mfrac></mrow></math>'),l[t]={name:t,current:d,limits:a[`max_${t}`],icon:h,sensor:m,unit_of_measurement:p}}}return(0,e.renderAttributeChunks)(t,l)},e.renderAttribute=(t,e)=>{const{max:i,min:s}=e.limits,c=e.unit_of_measurement,l=e.icon||"mdi:help-circle-outline",u=e.current||0,d=!isNaN(u),h=100*Math.max(0,Math.min(1,(u-s)/(i-s))),m=d?`${e.name}: ${u} ${c}<br>(${s} ~ ${i} ${c})`:t._hass.localize("state.default.unavailable"),p="dli"===e.name?'<math style="display: inline-grid;" xmlns="http://www.w3.org/1998/Math/MathML"><mrow><mfrac><mrow><mn>mol</mn></mrow><mrow><mn>d</mn><mn>⋅</mn><msup><mn>m</mn><mn>2</mn></msup></mrow></mfrac></mrow></math>':c,g="attribute tooltip "+(t.config.display_type===r.DisplayType.Compact?"width-100":"");return n.html`
        <div class="${g}" @click="${()=>(0,o.moreInfo)(t,e.sensor)}">
            <div class="tip" style="text-align:center;">${(0,a.unsafeHTML)(m)}</div>
            <ha-icon .icon="${l}"></ha-icon>
            <div class="meter red">
                <span class="${d?u<s||u>i?"bad":"good":"unavailable"}" style="width: 100%;"></span>
            </div>
            <div class="meter green">
                <span class="${d?u>i?"bad":"good":"unavailable"}" style="width:${d?h:"0"}%;"></span>
            </div>
            <div class="meter red">
                <span class="bad" style="width:${d?u>i?100:0:"0"}%;"></span>
            </div>
	    <div class="header"><span class="value">${u}</span>&nbsp;<span class='unit'>${(0,a.unsafeHTML)(p)}</span></div>
        </div>
    `},e.getChunkedDisplayed=(t,e)=>Object.values(t).reduce((t,i,r)=>{const n=Math.floor(r/e);return t[n]||(t[n]=[]),t[n].push(i),t},[]),e.renderAttributeChunks=(t,i)=>{const a=(0,e.getChunkedDisplayed)(i,t.config.display_type===r.DisplayType.Compact?1:2),s="attributes "+(t.config.display_type===r.DisplayType.Compact?"width-100":"");return a.map(i=>n.html`<div class="${s}">${i.map(i=>i?n.html`${(0,e.renderAttribute)(t,i)}`:"")}</div>`).flat()}},534:(t,e,i)=>{i.r(e),i.d(e,{UnsafeHTMLDirective:()=>a,unsafeHTML:()=>s});var r=i(752);class n{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}}class a extends n{constructor(t){if(super(t),this.it=r.s6,2!==t.type)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(t){if(t===r.s6||null==t)return this._t=void 0,this.it=t;if(t===r.c0)return t;if("string"!=typeof t)throw Error(this.constructor.directiveName+"() called with a non-string value");if(t===this.it)return this._t;this.it=t;const e=[t];return e.raw=e,this._t={_$litType$:this.constructor.resultType,strings:e,values:[]}}}a.directiveName="unsafeHTML",a.resultType=1;const s=(o=a,(...t)=>({_$litDirective$:o,values:t}));var o},752:(t,e,i)=>{i.d(e,{JW:()=>M,XX:()=>B,c0:()=>D,ej:()=>S,ge:()=>H,qy:()=>A,s6:()=>E});const r=globalThis,n=r.trustedTypes,a=n?n.createPolicy("lit-html",{createHTML:t=>t}):void 0,s="$lit$",o=`lit$${Math.random().toFixed(9).slice(2)}$`,c="?"+o,l=`<${c}>`,u=document,d=()=>u.createComment(""),h=t=>null===t||"object"!=typeof t&&"function"!=typeof t,m=Array.isArray,p=t=>m(t)||"function"==typeof t?.[Symbol.iterator],g="[ \t\n\f\r]",f=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,b=/-->/g,y=/>/g,_=RegExp(`>|${g}(?:([^\\s"'>=/]+)(${g}*=${g}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),v=/'/g,w=/"/g,$=/^(?:script|style|textarea|title)$/i,x=t=>(e,...i)=>({_$litType$:t,strings:e,values:i}),A=x(1),M=x(2),S=x(3),D=Symbol.for("lit-noChange"),E=Symbol.for("lit-nothing"),k=new WeakMap,N=u.createTreeWalker(u,129);function C(t,e){if(!m(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==a?a.createHTML(e):e}const T=(t,e)=>{const i=t.length-1,r=[];let n,a=2===e?"<svg>":3===e?"<math>":"",c=f;for(let e=0;e<i;e++){const i=t[e];let u,d,h=-1,m=0;for(;m<i.length&&(c.lastIndex=m,d=c.exec(i),null!==d);)m=c.lastIndex,c===f?"!--"===d[1]?c=b:void 0!==d[1]?c=y:void 0!==d[2]?($.test(d[2])&&(n=RegExp("</"+d[2],"g")),c=_):void 0!==d[3]&&(c=_):c===_?">"===d[0]?(c=n??f,h=-1):void 0===d[1]?h=-2:(h=c.lastIndex-d[2].length,u=d[1],c=void 0===d[3]?_:'"'===d[3]?w:v):c===w||c===v?c=_:c===b||c===y?c=f:(c=_,n=void 0);const p=c===_&&t[e+1].startsWith("/>")?" ":"";a+=c===f?i+l:h>=0?(r.push(u),i.slice(0,h)+s+i.slice(h)+o+p):i+o+(-2===h?e:p)}return[C(t,a+(t[i]||"<?>")+(2===e?"</svg>":3===e?"</math>":"")),r]};class I{constructor({strings:t,_$litType$:e},i){let r;this.parts=[];let a=0,l=0;const u=t.length-1,h=this.parts,[m,p]=T(t,e);if(this.el=I.createElement(m,i),N.currentNode=this.el.content,2===e||3===e){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes)}for(;null!==(r=N.nextNode())&&h.length<u;){if(1===r.nodeType){if(r.hasAttributes())for(const t of r.getAttributeNames())if(t.endsWith(s)){const e=p[l++],i=r.getAttribute(t).split(o),n=/([.?@])?(.*)/.exec(e);h.push({type:1,index:a,name:n[2],strings:i,ctor:"."===n[1]?P:"?"===n[1]?R:"@"===n[1]?z:U}),r.removeAttribute(t)}else t.startsWith(o)&&(h.push({type:6,index:a}),r.removeAttribute(t));if($.test(r.tagName)){const t=r.textContent.split(o),e=t.length-1;if(e>0){r.textContent=n?n.emptyScript:"";for(let i=0;i<e;i++)r.append(t[i],d()),N.nextNode(),h.push({type:2,index:++a});r.append(t[e],d())}}}else if(8===r.nodeType)if(r.data===c)h.push({type:2,index:a});else{let t=-1;for(;-1!==(t=r.data.indexOf(o,t+1));)h.push({type:7,index:a}),t+=o.length-1}a++}}static createElement(t,e){const i=u.createElement("template");return i.innerHTML=t,i}}function O(t,e,i=t,r){if(e===D)return e;let n=void 0!==r?i._$Co?.[r]:i._$Cl;const a=h(e)?void 0:e._$litDirective$;return n?.constructor!==a&&(n?._$AO?.(!1),void 0===a?n=void 0:(n=new a(t),n._$AT(t,i,r)),void 0!==r?(i._$Co??=[])[r]=n:i._$Cl=n),void 0!==n&&(e=O(t,n._$AS(t,e.values),n,r)),e}class L{constructor(t,e){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=e}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:e},parts:i}=this._$AD,r=(t?.creationScope??u).importNode(e,!0);N.currentNode=r;let n=N.nextNode(),a=0,s=0,o=i[0];for(;void 0!==o;){if(a===o.index){let e;2===o.type?e=new j(n,n.nextSibling,this,t):1===o.type?e=new o.ctor(n,o.name,o.strings,this,t):6===o.type&&(e=new F(n,this,t)),this._$AV.push(e),o=i[++s]}a!==o?.index&&(n=N.nextNode(),a++)}return N.currentNode=u,r}p(t){let e=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(t,i,e),e+=i.strings.length-2):i._$AI(t[e])),e++}}class j{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,e,i,r){this.type=2,this._$AH=E,this._$AN=void 0,this._$AA=t,this._$AB=e,this._$AM=i,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const e=this._$AM;return void 0!==e&&11===t?.nodeType&&(t=e.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,e=this){t=O(this,t,e),h(t)?t===E||null==t||""===t?(this._$AH!==E&&this._$AR(),this._$AH=E):t!==this._$AH&&t!==D&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):p(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==E&&h(this._$AH)?this._$AA.nextSibling.data=t:this.T(u.createTextNode(t)),this._$AH=t}$(t){const{values:e,_$litType$:i}=t,r="number"==typeof i?this._$AC(t):(void 0===i.el&&(i.el=I.createElement(C(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===r)this._$AH.p(e);else{const t=new L(r,this),i=t.u(this.options);t.p(e),this.T(i),this._$AH=t}}_$AC(t){let e=k.get(t.strings);return void 0===e&&k.set(t.strings,e=new I(t)),e}k(t){m(this._$AH)||(this._$AH=[],this._$AR());const e=this._$AH;let i,r=0;for(const n of t)r===e.length?e.push(i=new j(this.O(d()),this.O(d()),this,this.options)):i=e[r],i._$AI(n),r++;r<e.length&&(this._$AR(i&&i._$AB.nextSibling,r),e.length=r)}_$AR(t=this._$AA.nextSibling,e){for(this._$AP?.(!1,!0,e);t!==this._$AB;){const e=t.nextSibling;t.remove(),t=e}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t))}}class U{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,e,i,r,n){this.type=1,this._$AH=E,this._$AN=void 0,this.element=t,this.name=e,this._$AM=r,this.options=n,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=E}_$AI(t,e=this,i,r){const n=this.strings;let a=!1;if(void 0===n)t=O(this,t,e,0),a=!h(t)||t!==this._$AH&&t!==D,a&&(this._$AH=t);else{const r=t;let s,o;for(t=n[0],s=0;s<n.length-1;s++)o=O(this,r[i+s],e,s),o===D&&(o=this._$AH[s]),a||=!h(o)||o!==this._$AH[s],o===E?t=E:t!==E&&(t+=(o??"")+n[s+1]),this._$AH[s]=o}a&&!r&&this.j(t)}j(t){t===E?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class P extends U{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===E?void 0:t}}class R extends U{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==E)}}class z extends U{constructor(t,e,i,r,n){super(t,e,i,r,n),this.type=5}_$AI(t,e=this){if((t=O(this,t,e,0)??E)===D)return;const i=this._$AH,r=t===E&&i!==E||t.capture!==i.capture||t.once!==i.once||t.passive!==i.passive,n=t!==E&&(i===E||r);r&&this.element.removeEventListener(this.name,this,i),n&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class F{constructor(t,e,i){this.element=t,this.type=6,this._$AN=void 0,this._$AM=e,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(t){O(this,t)}}const H={M:s,P:o,A:c,C:1,L:T,R:L,D:p,V:O,I:j,H:U,N:R,U:z,B:P,F},q=r.litHtmlPolyfillSupport;q?.(I,j),(r.litHtmlVersions??=[]).push("3.3.1");const B=(t,e,i)=>{const r=i?.renderBefore??e;let n=r._$litPart$;if(void 0===n){const t=i?.renderBefore??null;r._$litPart$=n=new j(e.insertBefore(d(),t),t,void 0,i??{})}return n._$AI(t),n}},800:(t,e,i)=>{Object.defineProperty(e,"__esModule",{value:!0}),e.style=void 0;const r=i(337);e.style=r.css`
.card-margin-top {
  margin-top: 32px;
}
.problem-state {
  background-color: rgba(244, 67, 54, 0.3) !important;
  border: 2px solid rgba(244, 67, 54, 0.8) !important;
  box-shadow: 0 0 8px rgba(244, 67, 54, 0.4) !important;
}
.battery-warning-state {
  background-color: rgba(255, 152, 0, 0.3) !important;
  border: 2px solid rgba(255, 152, 0, 0.8) !important;
  box-shadow: 0 0 8px rgba(255, 152, 0, 0.4) !important;
}
.attributes {
  display: flex;
  white-space: nowrap;
  padding: 8px;
}
.attributes.width-100 {
  padding: 2px;

}
.attribute ha-icon {
  margin-right: 10px;
  margin-left: 5px;
}
.attribute {
  white-space: nowrap;
  display: flex;  
  align-items: center;
  width: 50%;
}
#battery {
  position: absolute;
  right: 10px;
  top: 8px;
}
#sensor-freshness {
  position: absolute;
  right: 10px;
  top: 33px;
  z-index: 1;
}
.freshness-badge {
  font-size: 0.62rem;
  font-weight: 600;
  line-height: 1.3;
  padding: 1px 5px;
  border: 1px solid transparent;
  border-radius: 7px;
  white-space: nowrap;
  letter-spacing: 0.2px;
  color: #f5f5f5;
  background: rgba(0, 0, 0, 0.45);
  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.5);
}
/* Schriftfarbe bleibt statisch hell (gut lesbar); das Freshness-Level
   wird nur über die Randfarbe angezeigt, nicht über die Schrift. */
.freshness-badge.fresh {
  border-color: rgba(129, 199, 132, 0.55);
}
.freshness-badge.warn {
  border-color: rgba(255, 193, 7, 0.6);
}
.freshness-badge.stale {
  border-color: rgba(244, 67, 54, 0.65);
}
.freshness-badge.unknown {
  border-color: rgba(158, 158, 158, 0.45);
}
/* Lesbarkeit auf eingefärbten Karten (orange/rot) sicherstellen:
   dunkler Chip-Hintergrund, damit der farbige Text Kontrast behält
   (verhindert "orange auf orange" im Battery-Warning-State). */
.battery-warning-state .freshness-badge,
.problem-state .freshness-badge {
  background: rgba(0, 0, 0, 0.5);
  text-shadow: 0 1px 1px rgba(0, 0, 0, 0.45);
}
/* No-Image: Akku steht im Flex-Flow rechts oben; Badge absolut darunter ausrichten */
.header.no-image > #sensor-freshness {
  right: 16px;
  top: 40px;
}
.header-compact.no-image > #sensor-freshness {
  right: 16px;
  top: 32px;
}
/* Ausnahme: Kompakt + ohne Bild + ohne Species -> kein Platz darunter,
   Badge bleibt links neben dem Akku (im Flex-Flow). */
.header-compact.no-image:not(:has(#species)) > #sensor-freshness {
  position: static;
  right: auto;
  top: auto;
  margin-left: 0;
  margin-right: 3px;
  align-self: flex-start;
}
.header {
  padding-top: 8px;
  height: 72px;
  position: relative;
}
.header-compact {
  padding-top: 4px;
  height: 50px;
  position: relative;
}
/* Ohne Trennlinie im Compact-Modus rücken die Sensorwerte direkt an
   den Header (Titel/Batterie) heran, damit die Karte niedriger wird. */
.header-compact + .attributes {
  padding-top: 0;
}
.attribute .header, .attribute .header-compact {
  height: auto;
  padding-top: 0px;
}
.header > img {
  border-radius: 50%;
  width: 88px;
  height: 88px;
  object-fit: cover;
  margin-left: 16px;
  margin-right: 16px;
  margin-top: -32px;
  float: left;
  box-shadow: var( --ha-card-box-shadow, 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2) );
}
.header-compact > img {
  border-radius: 50%;
  width: 50px;
  height: 50px;
  object-fit: cover;
  margin-left: 8px;
  margin-right: 8px;
  margin-top: 4px;
  margin-top: 0px;
  float: left;
  box-shadow: var( --ha-card-box-shadow, 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12), 0 3px 1px -2px rgba(0, 0, 0, 0.2) );
}
.header.no-image {
  height: auto;
  padding: 16px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.header.no-image + .divider {
  margin-top: 0;
}
.header-compact.no-image {
  height: auto;
  padding: 8px 16px;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.header.no-image > #name,
.header-compact.no-image > #name {
  flex: 1;
  min-width: 0;
  width: auto;
  margin-top: 0;
  margin-left: 0;
}
.header.no-image > #battery,
.header-compact.no-image > #battery {
  position: static;
  margin-top: 0;
  margin-left: auto;
}
.header.no-image > #species,
.header-compact.no-image > #species {
  width: 100%;
  margin-top: 2px;
}
.header > #name {
  font-weight: bold;
  width: 100%;
  margin-top: 16px;
  text-transform: capitalize;
  display: block;
}
.header-compact > #name {
  font-weight: bold;
  width: 100%;
  margin-top: 8px;
  text-transform: capitalize;
  display: block;
  white-space: nowrap;
}
#name ha-icon {
    color: rgb(240, 163, 163);
}
.header > #species {
  text-transform: capitalize;
  color: #8c96a5;
  display: block;
}
.header-compact > #species {
  text-transform: capitalize;
  line-height: 85%;
  color: #8c96a5;
  font-size: 0.8em;
  margin-top: 0px;
  margin-right: 4px;
  opacity: 0.4;
  display: block;
}
.meter {
  height: 8px;
  background-color: #f1f1f1;
  border-radius: 2px;
  display: inline-grid;
  overflow: hidden;
}
.meter.red {
  flex-grow: 1;
  margin-right: 5px;
  max-width: 5%
}
.meter.green {
  flex-grow: 10;
  margin-right: 5px;
  max-width: 40%
}
.attribute.tooltip.width-100 .meter.green {
  max-width: 90%;
}
.attribute.tooltip.width-100 .header {
  
}
.meter > span {
  grid-row: 1;
  grid-column: 1;
  height: 100%;
}
.meter > .good {
  background-color: rgba(43,194,83,1);
}
.meter > .bad {
  background-color: rgba(240,163,163);
}
.meter > .unavailable {
  background-color: rgba(158,158,158,1);
}
.divider {
  height: 1px;
  background-color: #727272;
  opacity: 0.25;
  margin-left: 8px;
  margin-right: 8px;
}
.tooltip {
  position: relative;
}
.tooltip .tip {
  opacity: 0;
  visibility: hidden;
  position: absolute;
  padding: 6px 10px;
  top: 3.3em;
  left: 50%;
  -webkit-transform: translateX(-50%) translateY(-180%);
          transform: translateX(-50%) translateY(-180%);
  background: grey;
  color: white;
  white-space: nowrap;
  z-index: 2;
  border-radius: 2px;
  transition: opacity 0.2s cubic-bezier(0.64, 0.09, 0.08, 1), -webkit-transform 0.2s cubic-bezier(0.64, 0.09, 0.08, 1);
  transition: opacity 0.2s cubic-bezier(0.64, 0.09, 0.08, 1), transform 0.2s cubic-bezier(0.64, 0.09, 0.08, 1);
  transition: opacity 0.2s cubic-bezier(0.64, 0.09, 0.08, 1), transform 0.2s cubic-bezier(0.64, 0.09, 0.08, 1), -webkit-transform 0.2s cubic-bezier(0.64, 0.09, 0.08, 1);
}
.battery.tooltip .tip {
  top: 2em;
}
.tooltip:hover .tip, .tooltip:active .tip {
  display: block;
  opacity: 1;
  visibility: visible;
  -webkit-transform: translateX(-50%) translateY(-200%);
          transform: translateX(-50%) translateY(-200%);
}
.width-100 {
  width: 100%;    
  margin-bottom: 3px;
  margin-right: 5px;
}
.width-100 .header {
  
}
@media (max-width: 600px) {
  .header > .unit {
    display: none;
  }
  .freshness-badge {
    font-size: 0.55rem;
    padding: 1px 4px;
  }
}
`},842:(t,e,i)=>{i.d(e,{BO:()=>o,mN:()=>S,Rf:()=>u,AH:()=>l,W3:()=>x,sk:()=>d,Ec:()=>A,qM:()=>n,iz:()=>c});const r=globalThis,n=r.ShadowRoot&&(void 0===r.ShadyCSS||r.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,a=Symbol(),s=new WeakMap;class o{constructor(t,e,i){if(this._$cssResult$=!0,i!==a)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t,this.t=e}get styleSheet(){let t=this.o;const e=this.t;if(n&&void 0===t){const i=void 0!==e&&1===e.length;i&&(t=s.get(e)),void 0===t&&((this.o=t=new CSSStyleSheet).replaceSync(this.cssText),i&&s.set(e,t))}return t}toString(){return this.cssText}}const c=t=>new o("string"==typeof t?t:t+"",void 0,a),l=(t,...e)=>{const i=1===t.length?t[0]:e.reduce((e,i,r)=>e+(t=>{if(!0===t._$cssResult$)return t.cssText;if("number"==typeof t)return t;throw Error("Value passed to 'css' function must be a 'css' function result: "+t+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+t[r+1],t[0]);return new o(i,t,a)},u=(t,e)=>{if(n)t.adoptedStyleSheets=e.map(t=>t instanceof CSSStyleSheet?t:t.styleSheet);else for(const i of e){const e=document.createElement("style"),n=r.litNonce;void 0!==n&&e.setAttribute("nonce",n),e.textContent=i.cssText,t.appendChild(e)}},d=n?t=>t:t=>t instanceof CSSStyleSheet?(t=>{let e="";for(const i of t.cssRules)e+=i.cssText;return c(e)})(t):t,{is:h,defineProperty:m,getOwnPropertyDescriptor:p,getOwnPropertyNames:g,getOwnPropertySymbols:f,getPrototypeOf:b}=Object,y=globalThis,_=y.trustedTypes,v=_?_.emptyScript:"",w=y.reactiveElementPolyfillSupport,$=(t,e)=>t,x={toAttribute(t,e){switch(e){case Boolean:t=t?v:null;break;case Object:case Array:t=null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){let i=t;switch(e){case Boolean:i=null!==t;break;case Number:i=null===t?null:Number(t);break;case Object:case Array:try{i=JSON.parse(t)}catch(t){i=null}}return i}},A=(t,e)=>!h(t,e),M={attribute:!0,type:String,converter:x,reflect:!1,useDefault:!1,hasChanged:A};Symbol.metadata??=Symbol("metadata"),y.litPropertyMetadata??=new WeakMap;class S extends HTMLElement{static addInitializer(t){this._$Ei(),(this.l??=[]).push(t)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(t,e=M){if(e.state&&(e.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(t)&&((e=Object.create(e)).wrapped=!0),this.elementProperties.set(t,e),!e.noAccessor){const i=Symbol(),r=this.getPropertyDescriptor(t,i,e);void 0!==r&&m(this.prototype,t,r)}}static getPropertyDescriptor(t,e,i){const{get:r,set:n}=p(this.prototype,t)??{get(){return this[e]},set(t){this[e]=t}};return{get:r,set(e){const a=r?.call(this);n?.call(this,e),this.requestUpdate(t,a,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(t){return this.elementProperties.get(t)??M}static _$Ei(){if(this.hasOwnProperty($("elementProperties")))return;const t=b(this);t.finalize(),void 0!==t.l&&(this.l=[...t.l]),this.elementProperties=new Map(t.elementProperties)}static finalize(){if(this.hasOwnProperty($("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty($("properties"))){const t=this.properties,e=[...g(t),...f(t)];for(const i of e)this.createProperty(i,t[i])}const t=this[Symbol.metadata];if(null!==t){const e=litPropertyMetadata.get(t);if(void 0!==e)for(const[t,i]of e)this.elementProperties.set(t,i)}this._$Eh=new Map;for(const[t,e]of this.elementProperties){const i=this._$Eu(t,e);void 0!==i&&this._$Eh.set(i,t)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(t){const e=[];if(Array.isArray(t)){const i=new Set(t.flat(1/0).reverse());for(const t of i)e.unshift(d(t))}else void 0!==t&&e.push(d(t));return e}static _$Eu(t,e){const i=e.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof t?t.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(t=>this.enableUpdating=t),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(t=>t(this))}addController(t){(this._$EO??=new Set).add(t),void 0!==this.renderRoot&&this.isConnected&&t.hostConnected?.()}removeController(t){this._$EO?.delete(t)}_$E_(){const t=new Map,e=this.constructor.elementProperties;for(const i of e.keys())this.hasOwnProperty(i)&&(t.set(i,this[i]),delete this[i]);t.size>0&&(this._$Ep=t)}createRenderRoot(){const t=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return u(t,this.constructor.elementStyles),t}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(t=>t.hostConnected?.())}enableUpdating(t){}disconnectedCallback(){this._$EO?.forEach(t=>t.hostDisconnected?.())}attributeChangedCallback(t,e,i){this._$AK(t,i)}_$ET(t,e){const i=this.constructor.elementProperties.get(t),r=this.constructor._$Eu(t,i);if(void 0!==r&&!0===i.reflect){const n=(void 0!==i.converter?.toAttribute?i.converter:x).toAttribute(e,i.type);this._$Em=t,null==n?this.removeAttribute(r):this.setAttribute(r,n),this._$Em=null}}_$AK(t,e){const i=this.constructor,r=i._$Eh.get(t);if(void 0!==r&&this._$Em!==r){const t=i.getPropertyOptions(r),n="function"==typeof t.converter?{fromAttribute:t.converter}:void 0!==t.converter?.fromAttribute?t.converter:x;this._$Em=r;const a=n.fromAttribute(e,t.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(t,e,i){if(void 0!==t){const r=this.constructor,n=this[t];if(i??=r.getPropertyOptions(t),!((i.hasChanged??A)(n,e)||i.useDefault&&i.reflect&&n===this._$Ej?.get(t)&&!this.hasAttribute(r._$Eu(t,i))))return;this.C(t,e,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(t,e,{useDefault:i,reflect:r,wrapped:n},a){i&&!(this._$Ej??=new Map).has(t)&&(this._$Ej.set(t,a??e??this[t]),!0!==n||void 0!==a)||(this._$AL.has(t)||(this.hasUpdated||i||(e=void 0),this._$AL.set(t,e)),!0===r&&this._$Em!==t&&(this._$Eq??=new Set).add(t))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(t){Promise.reject(t)}const t=this.scheduleUpdate();return null!=t&&await t,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[t,e]of this._$Ep)this[t]=e;this._$Ep=void 0}const t=this.constructor.elementProperties;if(t.size>0)for(const[e,i]of t){const{wrapped:t}=i,r=this[e];!0!==t||this._$AL.has(e)||void 0===r||this.C(e,void 0,i,r)}}let t=!1;const e=this._$AL;try{t=this.shouldUpdate(e),t?(this.willUpdate(e),this._$EO?.forEach(t=>t.hostUpdate?.()),this.update(e)):this._$EM()}catch(e){throw t=!1,this._$EM(),e}t&&this._$AE(e)}willUpdate(t){}_$AE(t){this._$EO?.forEach(t=>t.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(t)),this.updated(t)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(t){return!0}update(t){this._$Eq&&=this._$Eq.forEach(t=>this._$ET(t,this[t])),this._$EM()}updated(t){}firstUpdated(t){}}S.elementStyles=[],S.shadowRootOptions={mode:"open"},S[$("elementProperties")]=new Map,S[$("finalized")]=new Map,w?.({ReactiveElement:S}),(y.reactiveElementVersions??=[]).push("2.1.1")},854:(t,e)=>{var i;Object.defineProperty(e,"__esModule",{value:!0}),e.DisplayType=void 0,function(t){t.Full="full",t.Compact="compact"}(i||(e.DisplayType=i={}))},924:(t,e,i)=>{i.r(e),i.d(e,{customElement:()=>r,eventOptions:()=>l,property:()=>o,query:()=>d,queryAll:()=>m,queryAssignedElements:()=>g,queryAssignedNodes:()=>f,queryAsync:()=>p,standardProperty:()=>s,state:()=>c});const r=t=>(e,i)=>{void 0!==i?i.addInitializer(()=>{customElements.define(t,e)}):customElements.define(t,e)};var n=i(842);const a={attribute:!0,type:String,converter:n.W3,reflect:!1,hasChanged:n.Ec},s=(t=a,e,i)=>{const{kind:r,metadata:n}=i;let s=globalThis.litPropertyMetadata.get(n);if(void 0===s&&globalThis.litPropertyMetadata.set(n,s=new Map),"setter"===r&&((t=Object.create(t)).wrapped=!0),s.set(i.name,t),"accessor"===r){const{name:r}=i;return{set(i){const n=e.get.call(this);e.set.call(this,i),this.requestUpdate(r,n,t)},init(e){return void 0!==e&&this.C(r,void 0,t,e),e}}}if("setter"===r){const{name:r}=i;return function(i){const n=this[r];e.call(this,i),this.requestUpdate(r,n,t)}}throw Error("Unsupported decorator location: "+r)};function o(t){return(e,i)=>"object"==typeof i?s(t,e,i):((t,e,i)=>{const r=e.hasOwnProperty(i);return e.constructor.createProperty(i,t),r?Object.getOwnPropertyDescriptor(e,i):void 0})(t,e,i)}function c(t){return o({...t,state:!0,attribute:!1})}function l(t){return(e,i)=>{const r="function"==typeof e?e:e[i];Object.assign(r,t)}}const u=(t,e,i)=>(i.configurable=!0,i.enumerable=!0,Reflect.decorate&&"object"!=typeof e&&Object.defineProperty(t,e,i),i);function d(t,e){return(i,r,n)=>{const a=e=>e.renderRoot?.querySelector(t)??null;if(e){const{get:t,set:e}="object"==typeof r?i:n??(()=>{const t=Symbol();return{get(){return this[t]},set(e){this[t]=e}}})();return u(i,r,{get(){let i=t.call(this);return void 0===i&&(i=a(this),(null!==i||this.hasUpdated)&&e.call(this,i)),i}})}return u(i,r,{get(){return a(this)}})}}let h;function m(t){return(e,i)=>u(e,i,{get(){return(this.renderRoot??(h??=document.createDocumentFragment())).querySelectorAll(t)}})}function p(t){return(e,i)=>u(e,i,{async get(){return await this.updateComplete,this.renderRoot?.querySelector(t)??null}})}function g(t){return(e,i)=>{const{slot:r,selector:n}=t??{},a="slot"+(r?`[name=${r}]`:":not([name])");return u(e,i,{get(){const e=this.renderRoot?.querySelector(a),i=e?.assignedElements(t)??[];return void 0===n?i:i.filter(t=>t.matches(n))}})}}function f(t){return(e,i)=>{const{slot:r}=t??{},n="slot"+(r?`[name=${r}]`:":not([name])");return u(e,i,{get(){const e=this.renderRoot?.querySelector(n);return e?.assignedNodes(t)??[]}})}}}},e={};function i(r){var n=e[r];if(void 0!==n)return n.exports;var a=e[r]={exports:{}};return t[r].call(a.exports,a,a.exports,i),a.exports}i.d=(t,e)=>{for(var r in e)i.o(e,r)&&!i.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:e[r]})},i.o=(t,e)=>Object.prototype.hasOwnProperty.call(t,e),i.r=t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},i(248)})();